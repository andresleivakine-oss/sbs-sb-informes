@echo off
cd /d "%~dp0"
if not exist "python\python.exe" (
 echo Extrae el ZIP completo antes de instalar.
 pause
 exit /b 1
)
chcp 65001 >nul
"python\python.exe" install_local.py
pause
