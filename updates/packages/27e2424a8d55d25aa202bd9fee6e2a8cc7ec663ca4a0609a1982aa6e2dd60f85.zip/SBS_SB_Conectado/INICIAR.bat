@echo off
cd /d "%~dp0"
chcp 65001 >nul
if exist "python\python.exe" (
 "python\python.exe" server.py
) else if exist "%LOCALAPPDATA%\SBS_SB\python\python.exe" (
 "%LOCALAPPDATA%\SBS_SB\python\python.exe" server.py
) else (
 py -3 server.py
)
pause
