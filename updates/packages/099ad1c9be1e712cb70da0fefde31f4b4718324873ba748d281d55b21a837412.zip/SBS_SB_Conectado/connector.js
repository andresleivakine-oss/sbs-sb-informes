'use strict';
let apiSession='',selectedPatient=null,searchPage=0,historyPages=new Map(),seenTests=new Set(),requestVersion=0,configuration={vald:false,kinvent:false},loadedTests=[];
const msg=t=>document.getElementById('apiMessage').textContent=t;
async function callApi(path,body={}){if(!apiSession){const s=await fetch('/api/session').then(r=>r.json());apiSession=s.session}const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':apiSession},body:JSON.stringify(body),signal:AbortSignal.timeout(60000)});let d=await r.json();if(!r.ok)throw Error(d.error||'No se pudo consultar');return d}
async function runApi(fn){try{msg('Consultando…');await fn()}catch(e){msg(e.name==='TimeoutError'?'La consulta tardó más de 60 segundos. Inténtalo de nuevo.':e.message||'No se pudo conectar con el servicio local. Abre INICIAR.bat.')}}
function source(){return $('apiSource').value}
function clearClinical(){data.rows=[];data.patient='';data.diagnosis='';data.doctor='';data.initialDate='';data.controlDate='';data.suggestions='';data.clinicalReason='';data.clinicalFindings='';data.clinicalNextStep='';data.draft=false;editors();report()}
let searchVersion=0,searchProfileType=null,searchHasMore=false;
function resetPatientSearch(){
 searchVersion++;
 searchPage=0;
 searchProfileType=null;
 searchHasMore=false;
 $('apiPatients').replaceChildren();
 $('apiPrev').disabled=true;
 $('apiNext').disabled=true;
}
async function findPatients(){
 const provider=source();
 if(!configuration[provider])throw Error('Abre Conexiones y configura '+(provider==='vald'?'VALD':'Kinvent')+'. No hace falta cerrar ni reiniciar.');
 const version=++searchVersion;
 const page=searchPage;
 const query=$('apiQuery').value;
 $('apiPatients').replaceChildren();
 $('apiPrev').disabled=true;
 $('apiNext').disabled=true;
 let result;
 try{
  result=await callApi('search',{source:provider,query,page,refresh:true,athlete:$('apiAthlete').checked,profileType:searchProfileType});
 }catch(error){
  if(version===searchVersion)throw error;
  return;
 }
 if(version!==searchVersion)return;
 searchProfileType=result.profileType||null;
 searchHasMore=Boolean(result.hasMore);
 $('apiPrev').disabled=page===0;
 $('apiNext').disabled=!searchHasMore;
 for(const p of result.patients||[]){
  const button=document.createElement('button');
  button.style.cssText='display:block;width:100%;text-align:left;margin:7px 0';
  button.textContent=p.name+(p.birth?' · '+p.birth:'')+' · '+String(p.id).slice(-6);
  button.onclick=()=>runApi(()=>selectPatient(p));
  $('apiPatients').append(button);
 }
 const message=result.patients?.length?'Selecciona el perfil correcto para cargar evaluaciones.':
  page?'Sin resultados en esta página.':provider==='kinvent'?'Sin coincidencias en pacientes ni deportistas. Prueba con un apellido.':'No se encontraron perfiles.';
 msg(message);
}

function syncSource(){
 const isVald=source()==='vald';
 $('apiSystem').closest('label').hidden=!isVald;
 $('apiAthlete').closest('label').hidden=isVald;
 $('apiPrev').hidden=isVald;$('apiNext').hidden=isVald;
 $('apiTests').textContent='Actualizar evaluaciones '+(isVald?'VALD':'Kinvent');
 $('apiSourceNote').textContent=configuration[source()]?'Fuente de datos: '+(isVald?'VALD':'Kinvent')+'. Selecciona un paciente para cargar su historial.':(isVald?'VALD':'Kinvent')+' no está configurado. Abre Conexiones para introducir sus credenciales.';
}
async function selectPatient(p){
 const same=selectedPatient?.id===p.id&&selectedPatient?.source===p.source;
 const linkedKeys=data.rows.flatMap(row=>row.importKey?[row.importKey]:String(row.pairedImportKeys||'').split('\n').filter(Boolean));
 const restoredSame=!selectedPatient&&data.patient===p.name&&linkedKeys.length>0&&
  linkedKeys.every(key=>key.startsWith(p.source+'|'+p.id+'|'));
 const keepCase=same||restoredSame;
 if(!keepCase&&(data.rows.length||data.diagnosis||data.suggestions||data.clinicalReason||data.clinicalFindings||data.clinicalNextStep)&&!confirm('Cambiar de paciente vaciará el caso abierto. Guarda antes el informe si necesitas conservarlo. ¿Continuar?')){msg('Se conservó el paciente actual.');return;}
 selectedPatient=p;requestVersion++;
 if(!keepCase){clearClinical();data.patient=p.name;if(!data.centerPinned)setReportCenter(p.source==='vald'?'SBS':'SB');editors();report();}
 $('selectedPatient').textContent=(p.source==='vald'?'VALD':'Kinvent')+' · '+p.name+(p.birth?' · Nac. '+p.birth:'');
 $('apiHistory').hidden=false;syncSource();await startTests();
}
async function startTests(){
 historyPages=new Map();seenTests=new Set();loadedTests=[];$('apiTestList').replaceChildren();$('apiMetrics').replaceChildren();$('apiMore').hidden=true;
 $('apiHistoryNote').textContent='Consultando historial de '+(selectedPatient?.source==='vald'?'VALD':'Kinvent')+'…';
 msg('Cargando evaluaciones…');
 try{await loadTests(false)}catch(e){$('apiHistoryNote').textContent='La consulta de evaluaciones no se completó. '+e.message;throw e;}
}

$('apiSearch').onclick=()=>{resetPatientSearch();runApi(findPatients)};
$('apiQuery').onkeydown=event=>{if(event.key==='Enter')$('apiSearch').click()};
$('apiQuery').addEventListener('input',resetPatientSearch);
$('apiAthlete').onchange=resetPatientSearch;
$('apiNext').onclick=()=>{if(source()!=='kinvent'||!searchHasMore)return;searchPage++;runApi(findPatients)};
$('apiPrev').onclick=()=>{if(source()!=='kinvent'||searchPage===0)return;searchPage--;runApi(findPatients)};
$('apiSource').onchange=()=>{requestVersion++;selectedPatient=null;resetPatientSearch();$('apiHistory').hidden=true;$('apiMetrics').replaceChildren();syncSource();msg('Busca un paciente en la fuente elegida. El informe actual se conserva hasta seleccionar otro paciente.')};
function chileDayBoundary(day,end=false){
 const match=/^(\d{4})-(\d{2})-(\d{2})$/.exec(day);
 if(!match)throw Error('Selecciona fechas válidas.');
 const wanted=new Date(Date.UTC(+match[1],+match[2]-1,+match[3]+Number(end)));
 const formatter=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Santiago',year:'numeric',month:'2-digit',day:'2-digit'});
 const target=wanted.toISOString().slice(0,10);
 let low=wanted.getTime()-12*3600000,high=wanted.getTime()+12*3600000;
 while(high-low>1){
  const middle=Math.floor((high+low)/2);
  const parts=Object.fromEntries(formatter.formatToParts(new Date(middle)).map(({type,value})=>[type,value]));
  if(parts.year+'-'+parts.month+'-'+parts.day<target)low=middle;
  else high=middle;
 }
 return new Date(high).toISOString();
}
async function loadTests(more=false) {
 if(!selectedPatient)throw Error('Selecciona primero un paciente.');
 const version=++requestVersion,patient=selectedPatient;
 const choice=patient.source==='vald'?$('apiSystem').value:'kinvent';
 const systems=choice==='all'?['dyn','fd']:[choice];
 const pending=systems.filter(system=>!more||historyPages.get(system)?.more);
 const replies=await Promise.allSettled(pending.map(system=>{
  const previous=historyPages.get(system);
  return callApi('tests',{source:patient.source,patient:patient.id,system,
   start:$('apiFrom').value,end:$('apiTo').value,startUtc:chileDayBoundary($('apiFrom').value),endUtc:chileDayBoundary($('apiTo').value,true),page:(previous?.page||0)+1,cursor:previous?.cursor||''});
 }));
 if(version!==requestVersion)return;
 let added=0,failures=[],notes=[];
 for(const [index,reply] of replies.entries()){
  const system=pending[index],label={dyn:'DynaMo',fd:'ForceDecks',kinvent:'Kinvent'}[system];
  if(reply.status==='rejected'){
   failures.push(label+': '+reply.reason.message);
   continue;
  }
  const d=reply.value,previous=historyPages.get(system);
  const stalled=more&&d.cursor&&d.cursor===previous?.cursor;
  historyPages.set(system,{page:(previous?.page||0)+1,cursor:d.cursor||'',more:!!d.more&&!stalled});
  for(const test of d.tests||[]){
   if(seenTests.has(test.key))continue;
   seenTests.add(test.key);
   loadedTests.push(test);
   added++;
  }
  if(stalled)notes.push(label+': la paginación no avanzó.');
  if(d.received!==undefined)notes.push('Kinvent: '+d.received+' registros recibidos; '+(d.excluded||0)+' fuera del intervalo.');
 }
 renderTests();
 const hasMore=systems.some(system=>historyPages.get(system)?.more);
 $('apiMore').hidden=!hasMore;
 $('apiHistoryNote').textContent=[...notes,...failures,hasMore?'Usa Cargar más para continuar el historial.':''].filter(Boolean).join(' ');
 msg(added?added+' evaluaciones nuevas cargadas. Selecciona una para ver los KPI.':failures.length?failures.join(' · '):loadedTests.length?'Sin evaluaciones nuevas en esta página.':'No se encontraron evaluaciones en el intervalo indicado.');
}
$('apiTests').onclick=()=>runApi(startTests);
$('apiMore').onclick=()=>{$('apiMetrics').replaceChildren();runApi(()=>loadTests(true))};
function aggregate(m,how){if(!m.samples)return {...m.values};let vals={};for(const [limb,samples] of Object.entries(m.samples)){let n=samples.filter(x=>typeof x==='number'&&Number.isFinite(x));if(!n.length)continue;let side=limb.toLowerCase().includes('left')?'left':limb.toLowerCase().includes('right')?'right':'value';let v=how==='mean'?n.reduce((a,b)=>a+b,0)/n.length:how==='max'?Math.max(...n):n[+how];if(v===undefined)continue;if(vals[side]!==undefined)throw Error('Varios tipos de lado corresponden a la misma métrica. Selecciona otra métrica o registra manualmente.');vals[side]=v}return vals}
async function loadMetrics(t){const patientAtRequest=selectedPatient.id,version=++requestVersion;let d=dynamoLateralResponse(t,await callApi('metrics',{key:t.key,patient:patientAtRequest}));if(!selectedPatient||selectedPatient.id!==patientAtRequest||version!==requestVersion)return;$('apiMetrics').replaceChildren();const comparisons=loadComparisonCandidates(t,patientAtRequest,version);let heading=document.createElement('h3');heading.style.fontSize='14px';heading.textContent=t.title;$('apiMetrics').append(heading);const metrics=d.metrics||[];
const metricHost=document.createElement('div');
const jumps=metrics.filter(m=>m.group==='biomech');
if(metrics.length>1||jumps.length){
 const label=document.createElement('label');
 label.textContent=jumps.length?'Parámetro del salto':'Parámetro de la prueba';
 const chooser=document.createElement('select');
 const ordered=[...metrics].sort((a,b)=>Number(b.preferred)-Number(a.preferred)||Number(b.direction==='higher')-Number(a.direction==='higher'));
 const hasDefault=Boolean(jumps.length&&(ordered[0].preferred||ordered[0].direction==='higher'));
 if(!hasDefault){
  const placeholder=document.createElement('option');
  placeholder.textContent='Elige un parámetro';placeholder.value='';placeholder.disabled=true;placeholder.selected=true;
  chooser.append(placeholder);
 }
 for(const [i,m] of ordered.entries()){
  const option=document.createElement('option');
  option.value=String(i);
  option.textContent=(m.parameterName||m.name)+' · '+(m.unit||'sin unidad identificada');
  chooser.append(option);
 }
 label.append(chooser);
 $('apiMetrics').append(label);
 chooser.onchange=()=>showMetrics([ordered[Number(chooser.value)]]);
 $('apiMetrics').append(metricHost);
 if(hasDefault)showMetrics([ordered[0]]);
}else{
 $('apiMetrics').append(metricHost);
 showMetrics(metrics);
}
msg(d.note||'Revisa las métricas antes de cargar.');
function showMetrics(items){
 metricHost.replaceChildren();
 for(const m of items){let box=document.createElement('div');box.className='roweditor';let title=document.createElement('strong');title.textContent=m.name+' · '+(m.unit||'unidad sin identificar');box.append(title);let info=document.createElement('p');info.className='hint';info.textContent=m.protocol+' · '+m.method;box.append(info);let label=document.createElement('label');label.textContent='Nombre en el informe';let name=document.createElement('input');name.value=m.name;label.append(name);box.append(label);let method=document.createElement('select');if(m.samples){method.innerHTML='<option value="max">Máximo por lado / valor</option><option value="mean">Media por lado / valor</option>';let n=Math.min(...Object.values(m.samples).map(x=>x.length));for(let i=0;i<n;i++){let o=document.createElement('option');o.value=String(i);o.textContent='Registro '+(i+1)+' por lado (revisar orden)';method.append(o)}box.append(method)}else{method.innerHTML='<option value="summary">Resumen del proveedor</option>'}
let values=document.createElement('p');values.className='hint';const show=()=>{try{let v=aggregate(m,method.value);values.textContent=['left','right','value'].filter(k=>v[k]!==undefined).map(k=>({left:'Izq.',right:'Der.',value:'Resultado'}[k])+': '+fmt(v[k])+' '+m.unit).join(' · ');const a=asym(v.left,v.right);if(m.group==='biomech'&&a!==null)values.textContent+=' · Asimetría: '+fmt(a)+' %'+(v.left===v.right?'':v.left>v.right?' izq.':' der.')}catch(e){values.textContent=e.message}};method.onchange=show;box.append(values);show();let controls=document.createElement('div');controls.className='rowtools';for(let [slot,label] of [['initial','Cargar inicial'],['control','Cargar control']]){let b=document.createElement('button');b.textContent=label;b.onclick=()=>{try{if(!m.unit)throw Error('La API no identificó la unidad. No se importa por suposición.');let v=aggregate(m,method.value);if(!Object.keys(v).length)throw Error('No hay valores numéricos para importar.');if(importMetric(m,v,slot,name.value,method.value,d,selectedPatient,t))msg('Resultado cargado como '+(slot==='initial'?'inicial':'control')+'. Revisa la fila importada y define su meta.')}catch(e){msg(e.message)}};controls.append(b)}if(m.fingerprint&&m.unit){
 const hint=document.createElement('p');
 hint.className='hint';
 hint.textContent='Buscando evaluaciones compatibles en el historial cargado…';
 box.append(hint);
 const buttons=[['firstLast','Inicial y final'],['latest','Dos últimas']].map(([mode,caption])=>{
  const button=document.createElement('button');
  button.textContent=caption;
  button.hidden=true;
  controls.append(button);
  return {button,mode};
 });
 const linkedButtons=[['initial','Vincular Izq. y Der. como inicial'],['control','Vincular Izq. y Der. como control']].map(([slot,caption])=>{
  const button=document.createElement('button');
  button.textContent=caption;button.hidden=true;controls.append(button);
  return {button,slot};
 });
 const refresh=results=>{
  const linked=linkedDynamoSessions(m,t,d,results);
  const selected=linked.find(record=>record.response.test.split(' / ').includes(d.test));
  for(const {button,slot} of linkedButtons){
   button.hidden=!selected;
   button.onclick=()=>{if(version===requestVersion&&selected)runApi(()=>{
    if(importMetric(selected.metric,selected.metric.values,slot,selected.metric.name,'summary',selected.response,selectedPatient,t))
     msg('Izquierda y derecha vinculadas en una fila bilateral.');
   });};
  }
  if(selected){const {left,right}=selected.metric.values;values.textContent='Izq.: '+fmt(left)+' '+m.unit+' · Der.: '+fmt(right)+' '+m.unit;}
  const comparisonMetric=selected?.metric||m;
  const comparisonResponse=selected?.response||d;
  const comparisonResults=selected?linked.filter(record=>record!==selected):results;
  const pairs=buttons.map(({mode})=>comparisonPair(comparisonMetric,method.value,t,comparisonResponse,comparisonResults,mode));
  buttons.forEach(({button,mode},i)=>{
   button.hidden=!pairs[i];
   button.onclick=()=>{if(version===requestVersion&&pairs[i])runApi(()=>applyComparison(comparisonMetric,method.value,selected?comparisonMetric.name:name.value,t,pairs[i],mode));};
  });
  hint.textContent=pairs.some(Boolean)?'Hay dos o más evaluaciones compatibles en el historial cargado.':selected?'Hay un par de izquierda y derecha de la misma fecha.':'Sin dos evaluaciones compatibles en el historial cargado. Puedes ampliar las fechas o usar Cargar más.';
 };
 comparisons.then(results=>{
  if(version!==requestVersion)return;
  method.onchange=()=>{show();refresh(results)};
  refresh(results);
 });
}
box.append(controls);metricHost.append(box)}
}
}
function metricShape(values) {
 const sides=Object.keys(values).filter(key=>typeof values[key]==='number'&&Number.isFinite(values[key])).sort();
 if(!sides.length||sides.includes('value')&&sides.length>1)throw Error('La métrica necesita valores numéricos con una lateralidad consistente.');
 return sides.join(',');
}
function metricRow(metric,values,method,patient,test,label) {
 const shape=metricShape(values);
 const single=shape==='value';
 const key=metric.fingerprint?[patient.source,patient.id,metric.fingerprint,method,single?'single':shape==='left,right'?'sides':shape].join('|'):null;
 const existing=key?data.rows.find(row=>row.importKey===key):null;
 if(existing)return metric.group==='biomech'?{...existing,name:label,unit:metric.unit,direction:metric.direction||'review'}:{...existing};
 const provider=patient.source==='kinvent'?'Kinvent':test.source==='fd'?'VALD ForceDecks':'VALD DynaMo';
 const equipment=patient.source==='kinvent'?'Kinvent':'VALD';
 const aggregation=method==='max'?'máximo':method==='mean'?'media':metric.method;
 return {group:metric.group||'force',format:single?'single':'sides',name:label,unit:metric.unit,
  equipment,protocol:[provider,metric.group==='biomech'?'':metric.protocol,aggregation].filter(Boolean).join(' · '),initial:'',current:'',
  li:'',ri:'',lc:'',rc:'',metric:single?'current':data.side==='left'?'lc':'rc',op:'>=',goal:'',
  mode:'auto',direction:metric.direction||'review',importKey:key,origin:'',reviewed:false,kpi:metric.kpi||''};
}
function writeMetricSlot(row,slot,values,response,date) {
 const initial=slot==='initial';
 row[initial?'li':'lc']=values.left??'';
 row[initial?'ri':'rc']=values.right??'';
 row[initial?'initial':'current']=values.value??'';
 row[initial?'initialDate':'controlDate']=date;
 row[initial?'initialTest':'controlTest']=response.test;
 row[initial?'initialRecordedAt':'controlRecordedAt']=response.date||'';
}
function autoJoinImportedRow(index,patient){
 const row=data.rows[index];
 if(!row.importKey||!['left','right'].includes(row.importKey.split('|').at(-1)))return;
 const prefix=patient.source+'|'+patient.id+'|';
 const matches=(candidate)=>data.rows.flatMap((other,i)=>other.importKey?.startsWith(prefix)&&
  pairedRows(candidate,other)?[i]:[]);
 const candidates=matches(row);
 if(candidates.length===1&&matches(data.rows[candidates[0]]).length===1)joinSides(index,candidates[0],true);
}
function saveMetricRow(row,patient) {
 row.origin='Paciente '+patient.name+' · Inicial: '+(row.initialTest||'sin cargar')+' · Control: '+(row.controlTest||'sin cargar');
 row.reviewed=false;
 const index=row.importKey?data.rows.findIndex(x=>x.importKey===row.importKey):-1;
 if(index<0)data.rows.push(row);else data.rows[index]=row;
 autoJoinImportedRow(index<0?data.rows.length-1:index,patient);
 editors();
 report();
}
function evaluationDate(date) {
 const parsed=new Date(date);
 return date&&!isNaN(parsed)?parsed.toLocaleDateString('es-CL',{timeZone:'America/Santiago'}):'';
}
function importMetric(metric,values,slot,label,method,response,patient,test) {
 const date=evaluationDate(response.date)||prompt('Confirma la fecha de esta evaluación (dd/mm/aaaa):');
 if(!date)throw Error('Falta la fecha de la evaluación.');
 const row=metricRow(metric,values,method,patient,test,label);
 const initial=slot==='initial';
 if(row[initial?'controlTest':'initialTest']===response.test)throw Error('Elige otra evaluación para la segunda columna.');
 const testField=initial?'initialTest':'controlTest';
 if(row.importKey&&data.rows.some(existing=>String(existing.pairedImportKeys||'').split('\n').includes(row.importKey)&&
  String(existing[testField]||'').split(' / ').includes(String(response.test)))){
  msg('Esta evaluación ya está incluida en la fila bilateral.');
  return false;
 }
 const keys=initial?['li','ri','initial']:['lc','rc','current'];
 if(keys.some(key=>number(row[key])!==null)&&!confirm('Esta columna ya tiene datos. ¿Reemplazarlos?'))return false;
 writeMetricSlot(row,slot,values,response,date);
 row.comparisonMode='';
 saveMetricRow(row,patient);
 return true;
}
function dynamoLateralResponse(test,response){
 if(test.source!=='dyn')return response;
 return {...response,metrics:(response.metrics||[]).map(metric=>{
  const label=sideLabel(metric.name);
  if(!label)return metric;
  const values=metric.values||{};
  const keys=Object.keys(values);
  if(keys.length!==1||!['value',label.side].includes(keys[0])||!Number.isFinite(values[keys[0]]))return metric;
  return {...metric,values:{[label.side]:values[keys[0]]},dynamoSide:label.side,dynamoName:label.name};
 })};
}
function linkedDynamoSessions(metric,test,response,results){
 if(test.source!=='dyn'||!metric.dynamoSide)return [];
 const sessions=new Map();
 for(const record of [{test,response},...results]){
  const date=evaluationDate(record.response.date);
  if(!date)continue;
  for(const other of record.response.metrics||[]){
   if(!other.dynamoSide||other.unit!==metric.unit||other.group!==metric.group||
    other.protocol!==metric.protocol||other.method!==metric.method||pairText(other.dynamoName)!==pairText(metric.dynamoName))continue;
   if(!sessions.has(date))sessions.set(date,{left:[],right:[]});
   sessions.get(date)[other.dynamoSide].push({metric:other,response:record.response});
  }
 }
 const linked=[];
 for(const {left,right} of sessions.values()){
  if(left.length!==1||right.length!==1||left[0].response.test===right[0].response.test)continue;
  const a=left[0],b=right[0];
  const setup=['attachments','leftAttachment','rightAttachment'];
  if(setup.some(key=>a.metric.attachments?.[key]&&b.metric.attachments?.[key]&&
   a.metric.attachments[key]!==b.metric.attachments[key]))continue;
  const fingerprint=['DynaMo bilateral',a.metric.fingerprint,b.metric.fingerprint].join(':');
  const combined={...a.metric,name:metric.dynamoName,fingerprint,comparisonProtocol:null,values:{left:a.metric.values.left,right:b.metric.values.right}};
  const date=[a.response.date,b.response.date].sort()[0];
  linked.push({test,response:{test:[a.response.test,b.response.test].sort().join(' / '),date,metrics:[combined]},metric:combined});
 }
 return linked;
}
async function loadComparisonCandidates(test,patient,version) {
 const results=[];
 const candidates=loadedTests.filter(other=>other.key!==test.key&&other.source===test.source&&evaluationDate(other.date)&&(other.title===test.title||
  test.source==='dyn'&&other.kind===test.kind&&pairText(other.title)===pairText(test.title)));
 for(const other of candidates){
  if(requestVersion!==version)return [];
  try{
   const response=dynamoLateralResponse(other,await callApi('metrics',{key:other.key,patient}));
   results.push({response,test:other});
  }catch(error){continue;}
 }
 return results;
}
function attachmentCompatibility(metric,other) {
 if(other.unit!==metric.unit||other.group!==metric.group)return null;
 if(other.fingerprint===metric.fingerprint)return false;
 if(!metric.comparisonProtocol||metric.comparisonProtocol!==other.comparisonProtocol)return null;
 const normalize=value=>['','none','unknown'].includes(String(value??'').trim().toLowerCase())?'':String(value).trim();
 let unknown=false;
 for(const key of ['attachments','leftAttachment','rightAttachment']){
  const a=normalize(metric.attachments?.[key]),b=normalize(other.attachments?.[key]);
  if(a&&b&&a!==b)return null;
  if(a!==b)unknown=true;
 }
 return unknown;
}
function comparisonPair(metric,method,test,response,results,mode) {
 if(!evaluationDate(response.date))return null;
 let values,shape;
 try{values=aggregate(metric,method);shape=metricShape(values)}catch(error){return null}
 const records=[{metric,values,response,test}];
 for(const record of results){
  for(const other of record.response.metrics||[]){
   if(attachmentCompatibility(metric,other)===null)continue;
   try{
    const otherValues=aggregate(other,method);
    if(metricShape(otherValues)!==shape)continue;
    records.push({...record,metric:other,values:otherValues});
    break;
   }catch(error){continue;}
  }
 }
 const ordered=records.filter(r=>evaluationDate(r.response.date)).sort((a,b)=>Date.parse(a.response.date)-Date.parse(b.response.date));
 for(let last=ordered.length-1;last>0;last--){
  for(let first=mode==='latest'?last-1:0;first>=0&&first<last;first+=mode==='latest'?-1:1){
   const a=ordered[first],b=ordered[last];
   if(a.response.test===b.response.test||Date.parse(a.response.date)===Date.parse(b.response.date))continue;
   const unknown=attachmentCompatibility(a.metric,b.metric);
   if(unknown!==null)return {a,b,unknown};
  }
 }
 return null;
}
async function applyComparison(metric,method,label,test,pair,mode) {
 const patient=selectedPatient;
 const {a,b,unknown}=pair;
 const firstDate=evaluationDate(a.response.date);
 const lastDate=evaluationDate(b.response.date);
 const pairLabel=mode==='latest'?'Dos últimas':'Inicial y final';
 const warning=unknown?' VALD no especifica todos los accesorios en ambas evaluaciones. Confirma que el montaje fue el mismo.':'';
 if(!confirm(pairLabel+': '+firstDate+' → '+lastDate+'.'+warning+' ¿Cargar ambas evaluaciones?'))return;
 const row=metricRow(metric,aggregate(metric,method),method,patient,test,label);
 writeMetricSlot(row,'initial',a.values,a.response,firstDate);
 writeMetricSlot(row,'control',b.values,b.response,lastDate);
 row.comparisonMode=pairLabel;
 saveMetricRow(row,patient);
 msg(pairLabel+': '+firstDate+' → '+lastDate+'. Revisa la fila importada.');
}
// El HTML descargado conserva datos e identidad, sin secretos ni conexión obligatoria.
const baseSave=$('save').onclick;$('save').onclick=()=>{baseSave()};
$('apiSystem').onchange=()=>{if(selectedPatient?.source==='vald')runApi(startTests)};

function renderTests(){
 $('apiTestList').replaceChildren();
 const q=$('filterName').value.trim().toLocaleLowerCase('es'),kind=$('filterKind').value,region=$('filterRegion').value;
 const items=loadedTests.filter(t=>(!q||(t.title+' '+(t.originalTitle||'')).toLocaleLowerCase('es').includes(q))&&(!kind||t.kind===kind)&&(!region||t.region===region)).sort((a,b)=>(Date.parse(b.date)||0)-(Date.parse(a.date)||0));
 $('filterCount').textContent=items.length+' visibles de '+loadedTests.length+' evaluaciones cargadas. Recientes primero.';
 for(const t of items){let b=document.createElement('button');b.style.cssText='display:block;width:100%;text-align:left;margin:6px 0';const date=new Date(t.date);b.textContent=(!isNaN(date)?date.toLocaleString('es-CL',{timeZone:'America/Santiago'}):'Fecha por confirmar')+' · '+t.title;const label=document.createElement('small');label.textContent=(t.source==='fd'?'VALD ForceDecks':t.source==='dyn'?'VALD DynaMo':'Kinvent')+' · '+({force:'Fuerza',rom:'ROM',jump:'Salto',balance:'Equilibrio',endurance:'Resistencia',other:'Sin clasificar'}[t.kind]||'Revisar tipo');b.append(label);b.title=t.originalTitle||t.title;b.onclick=()=>runApi(()=>loadMetrics(t));$('apiTestList').append(b)}
}
for(const id of ['filterKind','filterRegion','filterName'])$(id).oninput=renderTests;
$('configProvider').onchange=()=>{const v=$('configProvider').value==='vald';$('valdConfigFields').hidden=!v;$('kinventConfigFields').hidden=v;$('configMessage').textContent='';};
function resetApiViews(){resetPatientSearch();selectedPatient=null;loadedTests=[];seenTests=new Set();$('apiHistory').hidden=true;$('apiPatients').replaceChildren();$('apiTestList').replaceChildren();$('apiMetrics').replaceChildren();}
document.addEventListener('saved-report-opened',()=>{
 requestVersion++;
 resetApiViews();
 searchPage=0;
 $('apiQuery').value=data.patient||'';
 msg('Informe guardado abierto. Puedes buscar el perfil para consultar nuevas evaluaciones.');
});
function showConnections(s){
 configuration={vald:!!s.vald,kinvent:!!s.kinvent};
 const label=k=>!s[k]?'sin configurar':s.verified?.[k]?'verificado ahora':s.saved?.[k]?'guardado · se comprobará al consultar':'configurado · sin comprobar en esta sesión';
 $('connection').textContent='VALD: '+label('vald')+' · Kinvent: '+label('kinvent')+' · v'+(s.version||'0.4');
 $('configRemember').disabled=!s.canRemember;
 if(!s.canRemember)$('configRemember').checked=false;
 if(s.storageWarning)$('configMessage').textContent=s.storageWarning;
 syncSource();
}
$('configConnect').onclick=async()=>{
 const provider=$('configProvider').value,b=$('configConnect');b.disabled=true;$('configMessage').textContent='Comprobando conexión…';
 try{const d=await callApi('configure',{provider,clientId:$('configClientId').value,tenant:$('configTenant').value,clientSecret:$('configSecret').value,apiKey:$('configKey').value,remember:$('configRemember').checked});requestVersion++;resetApiViews();showConnections(d);$('configSecret').value='';$('configKey').value='';$('configMessage').textContent=d.message;msg('Conexión lista. Puedes buscar pacientes sin reiniciar.');}
 catch(e){$('configMessage').textContent=e.message;}
 finally{b.disabled=false;}
};
$('configForget').onclick=async()=>{if(!confirm('Eliminar esta conexión del computador y de la sesión actual. ¿Continuar?'))return;try{const d=await callApi('configure',{provider:$('configProvider').value,forget:true});requestVersion++;resetApiViews();showConnections(d);$('configMessage').textContent=d.message;}catch(e){$('configMessage').textContent=e.message;}};
(function(){const today=new Date(),from=new Date();from.setFullYear(today.getFullYear()-1);$('apiTo').value=today.toLocaleDateString('en-CA');$('apiFrom').value=from.toLocaleDateString('en-CA');fetch('/api/session').then(r=>r.json()).then(s=>{apiSession=s.session;if(!s.vald&&s.kinvent)$('apiSource').value='kinvent';showConnections(s);if(!s.vald&&!s.kinvent){$('connectionsPanel').open=true;msg('Abre Conexiones para configurar ambos proveedores.');}}).catch(()=>{$('connection').textContent='Abre INICIAR.bat para conectar. El editor manual sigue disponible.'})})();

$('saveIdentity').onclick=async()=>{try{await callApi('identity',{brands:data.brands});$('identityMessage').textContent='Identidad guardada para ambos centros en este computador.';}catch(e){$('identityMessage').textContent=e.message;}};
fetch('/api/identity').then(r=>{if(!r.ok)throw Error('No disponible');return r.json()}).then(d=>{for(const k of ['SBS','SB'])if(d.brands?.[k])Object.assign(data.brands[k],d.brands[k]);editors();report();}).catch(()=>{});

let updateAvailable=false;
async function checkUpdates(silent=false){
 const button=$('checkUpdates');button.disabled=true;
 if(!silent)$('updateStatus').textContent='Consultando actualizaciones…';
 try{const d=await callApi('updates/check');updateAvailable=d.available;button.textContent=d.available?'Actualizar a '+d.latest:'Actualizar aplicación';$('updateStatus').textContent=d.available?'Hay una versión nueva: '+d.latest+'. La actualización conservará conexiones e identidad.':silent?'':'Ya tienes la versión más reciente ('+d.current+').';return d;}
 catch(e){if(!silent)$('updateStatus').textContent='No se pudo comprobar. Revisa internet e inténtalo de nuevo.';}
 finally{button.disabled=false;}
}
$('checkUpdates').onclick=async()=>{
 const d=await checkUpdates();if(!d?.available)return;
 if(!confirm('Se descargará e instalará la versión '+d.latest+' desde tu repositorio GitHub. La aplicación se reiniciará. Guarda el informe abierto antes de continuar. ¿Ya lo guardaste y quieres actualizar?'))return;
 $('checkUpdates').disabled=true;$('updateStatus').textContent='Descargando y verificando actualización…';
 try{const r=await callApi('updates/apply');$('updateStatus').textContent=r.message;}
 catch(e){$('updateStatus').textContent='No se completó la actualización. Puedes seguir usando esta versión. '+e.message;$('checkUpdates').disabled=false;}
};
checkUpdates(true);
